"This is the main file for the localmin task"
import sqlite3
from math import sqrt

def dotask(path_to_files):

	i=1
	x3=[]
	y3=[]
	x4=[]
	y4=[]
	filename=path_to_files+'task.db'#_'+tid+'.db'
	connection=sqlite3.connect(filename)
	x2=connection.execute("SELECT x FROM DATA")
	y2=connection.execute("SELECT y FROM DATA")
	for d in x2:
		x4.append(float(d[0]))
	for d in y2:
		y4.append(float(d[0]))
	connection.close()
	tid = str(int(x4.pop(0)))
	tid = str(int(y4.pop(0)))
	while(i>0 and i<(len(x4)-1)):
		if(y4[i]<y4[i+1] and y4[i]<y4[i-1] and i<=(len(x4)-2)):
			y3.append(y4[i])
			x3.append(x4[i])
			i+=2
		else:
			i+=1
	print(x4,y4)
	print(x3,y3)
	file=open(path_to_files+'/result.txt', 'w+')
	file.write(tid+'\n')
	for j in range(len(x3)):
		file.write(str(x3[j])+' '+str(y3[j])+'\n')
	
	print("T Id"+tid+"done")
	statfile = open(path_to_files+"projstat.txt", "w+")

	statfile.write("havF")
	statfile.write("comT")
	statfile.write("uplF")

	statfile.close()



if __name__=='__main__':
	dotask('')
