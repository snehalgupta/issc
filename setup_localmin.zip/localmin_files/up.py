import json
import subprocess
import time
import requests

def upload(path_to_files):

	count=0
	cnfm=True
	while (count<15):
		#result_file = 'abc.pdf'
		file = open(path_to_files+"result.txt", "r")

		tid=file.readline()
		tid = tid[:tid.find('\n')]
		
		file.close()

		print("Uploading Results of T Id "+tid+"...")
		url="http://issc.pythonanywhere.com/done/localmin/"+str(tid)
		#url="http://snehalgupta.pythonanywhere.com/done/localmin/"+str(tid)
		#url="http://127.0.0.1:8000/done/localmin/"+tid+"/"

		file1 = {'result_'+tid+'.txt':open(path_to_files+"result.txt", "rb")}
		post_fields = {'file': file1 }     # Set POST fields here
		print(post_fields)

		try:

			r = requests.post(url, files=file1)
			D = json.loads(r.text)
			#print(dict)
			if (D['conv']=='True'):
				print("Uploaded Results for T Id - "+tid)

			statfile = open(path_to_files+"projstat.txt", "w+")

			statfile.write("havF")
			statfile.write("comF")
			statfile.write("uplT")

			statfile.close()
			break

		except ValueError:
			print("There seems to be some problem with the connection")
			print("Please check your connection")
			print("Retrying......")
			pass


		
		count+=1
		time.sleep(5)
		

if __name__=='__main__':
	upload('')
