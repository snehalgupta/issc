from urllib.request import urlopen

import json

import subprocess

#url="http://snehalgupta.pythonanywhere.com"
url="http://127.0.0.1:8000"
print(url+"/export")
obj=urlopen(url+"/export")
obj2=obj.read()
obj3=obj2.decode("utf-8")

dict = json.loads(obj3)
print(dict)


#json string breakdown

if dict=={'alltasks':'done'}:
	print("Hurray! all tasks of this project are done!")
	exit()

#print(string)

file = open("Projectfiles/task.txt","w")

file.write(dict['taskid'])
file.write(":")
file.write(dict['task'])
file.close()
'''
cnfm=urlopen(url+"/igot/"+str(dict['taskid']))

print(url+"/igot/"+str(dict['taskid']))
'''

statfile = open("Projectfiles/projstat.txt", "w")

statfile.write("havT") #We are assuming once the user runs the app, he is willing to run the project until it is completed.
statfile.write("comF")
statfile.write("uplT")

statfile.close()

subprocess.call(["python3", "app.py"])
