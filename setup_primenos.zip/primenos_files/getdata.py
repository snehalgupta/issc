from urllib.request import urlopen

import json

import subprocess

import time

def gettask(path_to_files, username):
	i=0

	while(i<10):
		#try:
		print("Getting a task...")
		url="http://snehalgupta.pythonanywhere.com"
		#url="http://127.0.0.1:8000"
		#print(url+"/export")
		obj=urlopen(url+"/export/primenos")
		obj2=obj.read()
		obj3=obj2.decode("utf-8")

		dict = json.loads(obj3)
		print(dict)
		try:

			if dict['alltasks']=='done':
				print("Hurray! all tasks of this project are done! (or assigned)")
				file = open('Userstat_'+username+'.txt',"r")
				l=file.readlines()
				file.close()
				file = open('Userstat_'+username+'.txt',"w")
				for e in l:
					if 'primenos' in e:
						e=e[:e.find('\n')]+' (done)\n'
						print(e)
					file.write(e)
				file.close()
			i=10
			continue
		except:
			pass
		try:

			if dict['check after']!='':
				print("The program might get some task after about "+dict['check after'][:dict['check after'].find(' s')]+" seconds")
				file = open('Userstat_'+username+'.txt',"r")
				l=file.readlines()
				file.close()
				file = open('Userstat_'+username+'.txt',"w")
				for e in l:
					if 'primenos' in e:
						e=e[:e.find('\n')]+' (wait)\n'
						print(e)
					file.write(e)
				file.close()
				statfile = open(path_to_files+"projstat.txt", "w+")

				statfile.write("havF") #We are assuming once the user runs the app, he is willing to run the project until it is completed.
				statfile.write("comF")
				statfile.write("uplT")
				statfile.close()
			i=10
			continue
		except:
			pass
					
			

		print("Got Taskid - "+dict['taskid'], "Task - "+dict['task'])


		#json string breakdown

		

		#print(string)

		file = open(path_to_files+"task.txt","w+")

		file.write(dict['taskid'])
		file.write(":")
		file.write(dict['task'])
		file.close()
		print(dict)

			
		try:
			cnfm=urlopen(url+"/igot/primenos/"+str(dict['taskid']))
		except:
			pass

		statfile = open(path_to_files+"projstat.txt", "w+")

		statfile.write("havT") #We are assuming once the user runs the app, he is willing to run the project until it is completed.
		statfile.write("comF")
		statfile.write("uplT")
		statfile.close()

		file = open('Userstat_'+username+'.txt',"r")
		l=file.readlines()
		file.close()
		file = open('Userstat_'+username+'.txt',"w")
		for e in l:
			if 'primenos-Prime Numbers (wait)' in e:
				e='primenos-Prime Numbers\n'
				print(e)
			file.write(e)
		file.close()

		break
