def runproj(username):


	import primenos_files.main as main
	import primenos_files.up as up
	import primenos_files.getdata as getdata
	print("primenos")

	path_to_files='primenos_files/'

	file=open(path_to_files+"projstat.txt",'r')
	l2=file.readlines()
	l=l2[0]
	file.close()

	if l[l.find('v')+1]=='F':
		a=False
	else:
		a=True
	havtask= a

	if l[l.find('m')+1]=='F':
		a=False
	else:
		a=True
	completed = a

	uploaded = l[l.find('l')+1]

	print(havtask,completed,uploaded)



	if uploaded=='F':
		up.upload(path_to_files)

	elif havtask:
		main.dotask(path_to_files)

	else:
		getdata.gettask(path_to_files, username)
