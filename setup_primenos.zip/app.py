"""
This is the main program file
This will be responsible for managing the download and running of the project programs.
It
downloads the project files if not dowloaded
runs get tasks if task not assigned yet
uploads tasks if not uploaded
"""

import subprocess

'''file=open('projstat.txt',r)
l=file.readlines()

havetask= bool(l[0][2:])
completed = bool(l[1][2:])
uploaded = bool(l[2][2:])

if completed and !uploaded:
	subprocess.call("python3", "Projecfiles/up.py")

else:
	subprocess.call(["python3", "Projectfiles/getdata.py"])
	#subprocess.call(["python3", "Projectfiles/a.py"])
'''


subprocess.call(["python3", "Projectfiles/getdata.py"])
subprocess.call(["sleep", "2s"])
subprocess.call(["python3", "Projectfiles/a.py"])
