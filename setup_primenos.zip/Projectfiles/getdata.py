from urllib.request import urlopen

import json

#import subprocess

url="http://snehalgupta.pythonanywhere.com"

print(url+"/export")
obj=urlopen(url+"/export")
obj2=obj.read()
obj3=obj2.decode("utf-8")

dict = json.loads(obj3)
print(dict)


#json string breakdown



#print(string)

file = open("task.txt","w")

file.write(dict['taskid'])
file.write(":")
file.write(dict['task'])
file.close()


'''subprocess.call(["rm","projstat.txt"])
subprocess.call(["touch","projstat.txt"])

statfile = open("projstat.txt", "w")

statfile.write("havTrue") #We are assuming once the user runs the app, he is willing to run the project until it is completed.
statfile.write("comTrue")
statfile.write("uplFalse")

statfile.close()
'''
