from urllib.request import urlopen


print("launched upload.py")
file = open("result.txt", "r")

s=file.read()

res=s[:s.find(":")]
tid=s[s.find(":")+1:]

url="http://snehalgupta.pythonanywhere.com/done/"+str(tid)+"/"+str(res)

print(url)

obj=urlopen(url)

'''
subprocess.call(["rm","projstat.txt"])
subprocess.call(["touch","projstat.txt"])

statfile = open("projstat.txt", "w")

statfile.write("havFalse")
statfile.write("comTrue")
statfile.write("uplTrue")

statfile.close()
'''
