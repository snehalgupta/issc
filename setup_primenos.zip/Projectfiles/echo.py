import subprocess

subprocess.call(["pwd"])
